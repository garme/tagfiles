Slackware64 15.0 x86_64 — perfil core minimalista
Instalação em modo texto para rede e compilação

Este ZIP contém tagfiles baseados nas listas oficiais do Slackware64 15.0.
O perfil instala um sistema enxuto com rede, ferramentas de compilação e
suporte a inicialização BIOS e UEFI. É destinado a uma instalação sem
multilib; não inclui ambiente gráfico.

Seleção
-------

Série   Pacotes ADD   Conteúdo principal
A                70   Sistema base, kernel, firmware, ferramentas de disco,
                      LILO, GRUB e suporte UEFI (efibootmgr, efivar e elilo)
AP               11   slackpkg, sudo, nano, vim, neofetch, man e utilitários
D                20   GCC C/C++, binutils, make, Autotools, Git, Python 3,
                      Perl, CMake, Meson, Ninja e headers do kernel
L                41   glibc, bibliotecas de compilação e suporte aos aplicativos
N                32   NetworkManager, DHCP, iproute2, OpenSSH, NTP e diagnóstico

Total: 174 pacotes. As demais entradas e séries ficam marcadas SKP. O perfil
usa os kernels kernel-huge, kernel-generic e kernel-modules da arquitetura
x86_64; não seleciona variantes SMP, que não são fornecidas nesta série.
Inclui ext4 e XFS. A criação das partições e dos sistemas de arquivos é feita
no instalador.

Os pacotes solicitados em add.txt estão incluídos: vim, libsodium, libseccomp,
lynx, neofetch, ntp, xfsprogs e grub. Todos estão presentes na mídia oficial
do Slackware64 15.0.

Como usar
---------

1. Extraia o ZIP e copie a pasta tagfiles inteira para a raiz de um segundo
   pendrive, de preferência FAT32. Preserve a estrutura tagfiles/a/tagfile,
   tagfiles/ap/tagfile e as demais subpastas.

2. Inicie pela mídia oficial do Slackware64 15.0 e entre como root no
   instalador. Conecte o pendrive com os tagfiles e identifique a partição:

       lsblk -o NAME,SIZE,FSTYPE,LABEL,MOUNTPOINT

3. Monte a partição para leitura, substituindo /dev/sdX1 pela partição
   identificada:

       mkdir -p /tagmedia
       mount -o ro /dev/sdX1 /tagmedia

4. Execute setup. Configure TARGET e selecione a mídia oficial em SOURCE.
   Na tela SELECT, mantenha A, AP, D, L e N selecionadas. Escolha tagpath e
   informe /tagmedia/tagfiles.

5. Configure a inicialização conforme o firmware. Em BIOS, GRUB ou LILO podem
   ser usados. Em UEFI, use uma ESP FAT já existente ou crie uma; configure
   GRUB ou ELILO e confirme a entrada UEFI antes de reiniciar. efibootmgr e
   efivar estão disponíveis para administrar as variáveis de firmware.
   Para iniciar com kernel generic, gere o initrd conforme
   /boot/README.initrd e atualize a configuração do carregador.

6. Em CONFIGURE, escolha NetworkManager para habilitar a rede. Ative SSH
   somente se precisar receber conexões.

Depois do primeiro boot
-----------------------

Para conectar ao Wi-Fi, execute nmtui como root. Em rede cabeada com DHCP,
conecte o cabo.

    nmtui
    nmcli device status
    ip -br address
    ip route

Verifique a compilação C e C++:

    printf 'int main(void) { return 0; }\n' | gcc -x c - -o /tmp/teste-gcc
    /tmp/teste-gcc && echo 'C OK'
    printf 'int main() { return 0; }\n' | g++ -x c++ - -o /tmp/teste-gxx
    /tmp/teste-gxx && echo 'C++ OK'

Configure um único espelho slackware64-15.0 em /etc/slackpkg/mirrors. Como
root, execute slackpkg update gpg, slackpkg update, slackpkg install-new e
slackpkg upgrade-all. Revise install-new para preservar o perfil enxuto.
Antes de atualizar o kernel, revise o carregador, regenere initrd quando
necessário e confirme que uma entrada de recuperação continua disponível.

Referências
-----------

https://mirror.slackbuilds.org/slackware/slackware64-15.0/slackware64/
https://mirror.slackbuilds.org/slackware/slackware64-15.0/README_UEFI.TXT
https://docs.slackware.com/slackware:install
https://docs.slackware.com/slackware:slackpkg
