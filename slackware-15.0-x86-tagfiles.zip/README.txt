Slackware 15.0 x86 de 32 bits
Instalação em modo texto para rede e compilação

O arquivo contém tagfiles para o instalador padrão da ISO Slackware 15.0
de 32 bits. Use uma máquina x86 em modo Legacy BIOS (ou CSM, se houver).
O perfil foi montado para instalação convencional em BIOS/Legacy. Inclui ferramentas para ext4 e XFS; a criação das partições e dos sistemas de arquivos continua sendo feita no instalador.

Seleção
-------

Série   Pacotes ADD   Conteúdo principal
A                70   Sistema base, kernel, módulos, firmware, LILO, GRUB,
                      mkinitrd e ferramentas para XFS
AP               11   slackpkg, sudo, nano, vim, neofetch, man e utilitários
D                20   GCC C/C++, binutils, make, Autotools, Git, Python 3,
                      Perl, CMake, Meson, Ninja e headers do kernel
L                41   glibc, bibliotecas do compilador e suporte aos aplicativos
N                32   NetworkManager, DHCP, iproute2, OpenSSH, NTP e diagnóstico

Total de 174 pacotes. A soma dos tamanhos descompactados no catálogo da ISO
é de cerca de 2,4 GiB. Reserve espaço adicional para atualizações, arquivos
temporários e projetos. As demais séries têm somente entradas SKP. Os kernels
SMP e sem SMP, com seus módulos, foram incluídos para cobrir PCs x86 antigos.

Os programas de rede incluem curl, wget, rsync, tcpdump, ethtool, iptables, lynx e ntp. O vim está incluído como editor adicional; o GRUB foi incluído junto ao LILO. libsodium e libseccomp ampliam o conjunto de bibliotecas disponíveis.
A rede pode ser gerenciada pelo NetworkManager com nmtui (menu em modo
texto) ou nmcli (linha de comando). O perfil inclui libndp, mozilla-nss e
newt, além de D-Bus, wpa_supplicant e dhcpcd. A seleção cobre Ethernet e
Wi-Fi administrados como root. Os plugins de modem celular, Bluetooth e
Open vSwitch têm dependências próprias.

Como usar
---------

1. Extraia este ZIP antes de iniciar a instalação. Copie a pasta tagfiles
   inteira para a raiz de um segundo pendrive, de preferência FAT32.
   A estrutura no pendrive deve conter tagfiles/a/tagfile, tagfiles/ap/tagfile
   e as demais subpastas da mesma forma.

2. Inicie pela mídia oficial do Slackware 15.0 de 32 bits. Entre como root
   no console do instalador. Conecte o segundo pendrive e identifique a
   partição dele pela capacidade ou pelo rótulo.

       lsblk -o NAME,SIZE,FSTYPE,LABEL,MOUNTPOINT

3. Monte essa partição para leitura. Substitua /dev/sdX1 pela partição
   identificada no passo anterior.

       mkdir -p /tagmedia
       mount -o ro /dev/sdX1 /tagmedia
       ls /tagmedia/tagfiles/{a,ap,d,l,n}/tagfile

4. Execute setup. Configure TARGET e escolha a mídia oficial em SOURCE.
   O pendrive com as listas serve apenas para a etapa tagpath.

5. Na tela SELECT, deixe marcadas A, AP, D, L e N. Na tela de modo de
   instalação, escolha tagpath e informe exatamente este diretório.

       /tagmedia/tagfiles

   O caminho deve apontar para a pasta que contém a/, ap/, d/, l/ e n/.

6. Conclua CONFIGURE e configure a inicialização, por exemplo com o LILO em
   um disco dedicado. A mídia usa hugesmp.s como padrão. Se o seu processador
   exigiu huge.s para iniciar o instalador, confira se o carregador aponta
   para o kernel sem SMP instalado em /boot. Para iniciar com um kernel
   generic, prepare antes o initrd conforme /boot/README.initrd.

7. Em CONFIGURE, escolha NetworkManager no menu de configuração de rede.
   Essa opção habilita o serviço para iniciar com o sistema. Se você pular
   esta etapa, execute netconfig como root no console local, escolha
   NetworkManager e reinicie. Se já houver uma configuração manual de rede
   no rc.inet1.conf, guarde uma cópia antes de executar netconfig.
   Ative o serviço SSH apenas se você precisar receber conexões.

Depois do primeiro boot
-----------------------

Para conectar ao Wi-Fi, execute nmtui como root. Escolha “Ativar uma
conexão”, selecione a rede e informe a senha. O NetworkManager guarda
o perfil para reconexão. Em uma rede cabeada com DHCP, conecte o cabo.

    nmtui
    nmcli device status

Para verificar rede e compilação:

    ip -br address
    ip route
    curl -I https://www.slackware.com/
    printf 'int main(void) { return 0; }\n' | gcc -x c - -o /tmp/teste-gcc
    /tmp/teste-gcc && echo 'C OK'
    printf 'int main() { return 0; }\n' | g++ -x c++ - -o /tmp/teste-gxx
    /tmp/teste-gxx && echo 'C++ OK'

Habilite um único espelho de slackware-15.0 (32 bits) em
/etc/slackpkg/mirrors. Como root, execute:

    slackpkg update gpg
    slackpkg update
    slackpkg install-new
    slackpkg upgrade-all

Revise a lista de install-new para preservar o perfil enxuto. Ao atualizar
o kernel, revise a imagem configurada no carregador, regenere o initrd se
o kernel em uso o exigir e execute lilo antes de reiniciar caso use LILO.

Para acrescentar um pacote durante a instalação, altere a linha dele de
SKP para ADD no tagfile da série e confira as dependências. Depois do boot, use slackpkg install seguido
do nome do pacote. Para projetos específicos, instale as bibliotecas
pedidas pelo sistema de compilação do projeto.

Referências
-----------

https://mirror.slackbuilds.org/slackware/slackware-15.0/slackware/
https://mirror.slackbuilds.org/slackware/slackware-15.0/README_UEFI.TXT
https://docs.slackware.com/slackware:install
https://docs.slackware.com/slackware:slackpkg
